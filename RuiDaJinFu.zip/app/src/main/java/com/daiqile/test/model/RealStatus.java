package com.daiqile.test.model;

/**
 * Created by Administrator on 2017/1/18.
 */
public class RealStatus {


    /**
     * username : www
     * realname : 李永富
     * card_id : 341222199003048755
     * province : 安徽省
     * city : 阜阳
     * area : 太和县
     * real_status : 1
     */

    private String username;
    private String realname;
    private String card_id;
    private String province;
    private String city;
    private String area;
    private String real_status;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getCard_id() {
        return card_id;
    }

    public void setCard_id(String card_id) {
        this.card_id = card_id;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getReal_status() {
        return real_status;
    }

    public void setReal_status(String real_status) {
        this.real_status = real_status;
    }
}
