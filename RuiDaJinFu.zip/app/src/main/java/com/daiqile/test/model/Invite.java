package com.daiqile.test.model;

/**
 * Created by ZHY_9 on 2017/6/22.
 */

public class Invite {

    private String status;

    private String url;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
