package com.daiqile.test.model;

/**
 * Created by Administrator on 2016/12/13.
 */
public class AccountCenter {

    /**
     * jinzhi : 0
     * amount : 2000
     * recharge_success : null
     * recharge : null
     * recharge_false : null
     * borrow_account : null
     * payment_times : 0
     * borrow_times : 0
     * max_account : 2000
     * collection_wait : 0
     * collection_yes : 0
     * collection_capital1 : 0
     * collection_repaytime :
     * wait_payment : 0
     * borrow_num : 0
     * use_amount : 0
     * id : null
     * user_id : 27
     * credit : null
     * credit_use : 2000.00
     * credit_nouse : 0.00
     * borrow_vouch : 0.00
     * borrow_vouch_use : 0.00
     * borrow_vouch_nouse : 0.00
     * tender_vouch : 0.00
     * tender_vouch_use : 0.00
     * tender_vouch_nouse : 0.00
     * new_repay_time :
     * new_repay_account :
     * new_collection_time :
     * new_collection_account :
     * num_late_repay_account : null
     * num_late_interes : null
     * no_use_money : null
     * credit_fen : null
     * typepurview :
     * typename : 普通用户
     * type : 2
     * kefu_userid : null
     * kefu_username : null
     * kefu_addtime : null
     * vip_status : 0
     * vip_remark : null
     * vip_money : null
     * vip_verify_remark : null
     * vip_verify_time : null
     * bbs_topics_num : 0
     * bbs_posts_num : 0
     * account : 0
     * account_use : 0
     * account_nouse : 0
     * account_waitin : 0
     * account_waitintrest : 0
     * account_intrest : 0
     * account_award : 0
     * account_payment : 0
     * account_expired : 0
     * account_waitvip : 0
     * borrow_amount : 2000
     * vouch_amount : 0
     * borrow_loan : 0
     * borrow_success : 0
     * borrow_wait : 0
     * borrow_paymeng : 0
     * friends_apply : 0
     * vip_deadline : null
     * vip_newmoney : null
     * total : null
     * use_money : null
     * collection : null
     * xutou : null
     * fund : null
     * lockmoney : null
     * xtcoll : null
     * lock_xtcoll : null
     * xtjl : null
     * site_id : null
     * name : null
     * status : 0
     * order : null
     * hits : null
     * litpic : null
     * flag : null
     * source : null
     * publish : null
     * marry : null
     * child : null
     * education : null
     * income : null
     * shebao : null
     * shebaoid : null
     * housing : null
     * car : null
     * late : null
     * house_address : null
     * house_area : null
     * house_year : null
     * house_status : null
     * house_holder1 : null
     * house_holder2 : null
     * house_right1 : null
     * house_right2 : null
     * house_loanyear : null
     * house_loanprice : null
     * house_balance : null
     * house_bank : null
     * company_name : null
     * company_type : null
     * company_industry : null
     * company_office : null
     * company_jibie : null
     * company_worktime1 : null
     * company_worktime2 : null
     * company_workyear : null
     * company_tel : null
     * company_address : null
     * company_weburl : null
     * company_reamrk : null
     * private_type : null
     * private_date : null
     * private_place : null
     * private_rent : null
     * private_term : null
     * private_taxid : null
     * private_commerceid : null
     * private_income : null
     * private_employee : null
     * finance_repayment : null
     * finance_property : null
     * finance_amount : null
     * finance_car : null
     * finance_caramount : null
     * finance_creditcard : null
     * mate_name : null
     * mate_salary : null
     * mate_phone : null
     * mate_tel : null
     * mate_type : null
     * mate_office : null
     * mate_address : null
     * mate_income : null
     * education_record : null
     * education_school : null
     * education_study : null
     * education_time1 : null
     * education_time2 : null
     * tel : null
     * phone : 12586945655
     * post : null
     * address : null
     * province : null
     * city : null
     * area : null
     * linkman1 : null
     * relation1 : null
     * tel1 : null
     * phone1 : null
     * linkman2 : null
     * relation2 : null
     * tel2 : null
     * phone2 : null
     * linkman3 : null
     * relation3 : null
     * tel3 : null
     * phone3 : null
     * msn : null
     * qq : null
     * wangwang : null
     * ability : null
     * interest : null
     * others : null
     * experience : null
     * sex : null
     * addtime : 1481168548
     * addip : 60.178.207.3
     * updatetime : null
     * updateip : null
     * type_id : 2
     * purview : null
     * username : test11
     * password : 08622aba0c3e6b01d209cea0220c13bb
     * paypassword : null
     * islock : 0
     * isinvite : 0
     * invite_userid : null
     * invite_money : 0.00
     * real_status : null
     * card_type : null
     * card_id : null
     * card_pic1 : null
     * card_pic2 : null
     * nation : null
     * realname :
     * integral : 0
     * invest_integral : 0
     * wx_invest_integral : 0
     * avatar_status : 0
     * email_status : null
     * phone_status : 0
     * video_status : 0
     * scene_status : 0
     * email :
     * question : null
     * answer : null
     * birthday : null
     * remind : null
     * privacy :
     * logintime : 0
     * uptime : 1481168548
     * upip : 60.178.207.3
     * lasttime : 1481168548
     * lastip : 60.178.207.3
     * chongzu_id : 0
     * cz_money : 0.00
     * cz_cash : 0.00
     * chongzu_new_id : 0
     * usecredit : null
     * message : 0
     * headimg : /data/images/avatar/noavatar_middle.gif
     */

    private String jinzhi;
    private String amount;
    private Object recharge_success;
    private Object recharge;
    private Object recharge_false;
    private Object borrow_account;
    private String payment_times;
    private String borrow_times;
    private String max_account;
    private String collection_wait;
    private String collection_yes;
    private String collection_capital1;
    private String collection_repaytime;
    private String wait_payment;
    private String borrow_num;
    private String use_amount;
    private Object id;
    private String user_id;
    private Object credit;
    private String credit_use;
    private String credit_nouse;
    private String borrow_vouch;
    private String borrow_vouch_use;
    private String borrow_vouch_nouse;
    private String tender_vouch;
    private String tender_vouch_use;
    private String tender_vouch_nouse;
    private String new_repay_time;
    private String new_repay_account;
    private String new_collection_time;
    private String new_collection_account;
    private Object num_late_repay_account;
    private Object num_late_interes;
    private double no_use_money;
    private Object credit_fen;
    private String typepurview;
    private String typename;
    private String type;
    private Object kefu_userid;
    private Object kefu_username;
    private Object kefu_addtime;
    private String vip_status;
    private Object vip_remark;
    private Object vip_money;
    private Object vip_verify_remark;
    private Object vip_verify_time;
    private String bbs_topics_num;
    private String bbs_posts_num;
    private String account;
    private String account_use;
    private String account_nouse;
    private String account_waitin;
    private String account_waitintrest;
    private String account_intrest;
    private String account_award;
    private String account_payment;
    private String account_expired;
    private String account_waitvip;
    private String borrow_amount;
    private String vouch_amount;
    private String borrow_loan;
    private String borrow_success;
    private String borrow_wait;
    private String borrow_paymeng;
    private String friends_apply;
    private Object vip_deadline;
    private Object vip_newmoney;
    private double total;
    private double use_money;
    private float collection;
    private double use_learn_money;
    private Object xutou;
    private Object fund;
    private Object lockmoney;
    private Object xtcoll;
    private Object lock_xtcoll;
    private Object xtjl;
    private Object site_id;
    private Object name;
    private String status;
    private Object order;
    private Object hits;
    private Object litpic;
    private Object flag;
    private Object source;
    private Object publish;
    private Object marry;
    private Object child;
    private Object education;
    private Object income;
    private Object shebao;
    private Object shebaoid;
    private Object housing;
    private Object car;
    private Object late;
    private Object house_address;
    private Object house_area;
    private Object house_year;
    private Object house_status;
    private Object house_holder1;
    private Object house_holder2;
    private Object house_right1;
    private Object house_right2;
    private Object house_loanyear;
    private Object house_loanprice;
    private Object house_balance;
    private Object house_bank;
    private Object company_name;
    private Object company_type;
    private Object company_industry;
    private Object company_office;
    private Object company_jibie;
    private Object company_worktime1;
    private Object company_worktime2;
    private Object company_workyear;
    private Object company_tel;
    private Object company_address;
    private Object company_weburl;
    private Object company_reamrk;
    private Object private_type;
    private Object private_date;
    private Object private_place;
    private Object private_rent;
    private Object private_term;
    private Object private_taxid;
    private Object private_commerceid;
    private Object private_income;
    private Object private_employee;
    private Object finance_repayment;
    private Object finance_property;
    private Object finance_amount;
    private Object finance_car;
    private Object finance_caramount;
    private Object finance_creditcard;
    private Object mate_name;
    private Object mate_salary;
    private Object mate_phone;
    private Object mate_tel;
    private Object mate_type;
    private Object mate_office;
    private Object mate_address;
    private Object mate_income;
    private Object education_record;
    private Object education_school;
    private Object education_study;
    private Object education_time1;
    private Object education_time2;
    private Object tel;
    private String phone;
    private Object post;
    private Object address;
    private Object province;
    private Object city;
    private Object area;
    private Object linkman1;
    private Object relation1;
    private Object tel1;
    private Object phone1;
    private Object linkman2;
    private Object relation2;
    private Object tel2;
    private Object phone2;
    private Object linkman3;
    private Object relation3;
    private Object tel3;
    private Object phone3;
    private Object msn;
    private Object qq;
    private Object wangwang;
    private Object ability;
    private Object interest;
    private Object others;
    private Object experience;
    private Object sex;
    private String addtime;
    private String addip;
    private Object updatetime;
    private Object updateip;
    private String type_id;
    private Object purview;
    private String username;
    private String password;
    private Object paypassword;
    private String islock;
    private String isinvite;
    private Object invite_userid;
    private String invite_money;
    private Object real_status;
    private Object card_type;
    private Object card_id;
    private Object card_pic1;
    private Object card_pic2;
    private Object nation;
    private String realname;
    private String integral;
    private String invest_integral;
    private String wx_invest_integral;
    private String avatar_status;
    private Object email_status;
    private String phone_status;
    private String video_status;
    private String scene_status;
    private String email;
    private Object question;
    private Object answer;
    private Object birthday;
    private Object remind;
    private String privacy;
    private String logintime;
    private String uptime;
    private String upip;
    private String lasttime;
    private String lastip;
    private String chongzu_id;
    private String cz_money;
    private String cz_cash;
    private String chongzu_new_id;
    private Object usecredit;
    private String message;
    private String headimg;

    public String getJinzhi() {
        return jinzhi;
    }

    public double getUse_learn_money() {
        return use_learn_money;
    }

    public void setUse_learn_money(double use_learn_money) {
        this.use_learn_money = use_learn_money;
    }

    public void setJinzhi(String jinzhi) {
        this.jinzhi = jinzhi;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public Object getRecharge_success() {
        return recharge_success;
    }

    public void setRecharge_success(Object recharge_success) {
        this.recharge_success = recharge_success;
    }

    public Object getRecharge() {
        return recharge;
    }

    public void setRecharge(Object recharge) {
        this.recharge = recharge;
    }

    public Object getRecharge_false() {
        return recharge_false;
    }

    public void setRecharge_false(Object recharge_false) {
        this.recharge_false = recharge_false;
    }

    public Object getBorrow_account() {
        return borrow_account;
    }

    public void setBorrow_account(Object borrow_account) {
        this.borrow_account = borrow_account;
    }

    public String getPayment_times() {
        return payment_times;
    }

    public void setPayment_times(String payment_times) {
        this.payment_times = payment_times;
    }

    public String getBorrow_times() {
        return borrow_times;
    }

    public void setBorrow_times(String borrow_times) {
        this.borrow_times = borrow_times;
    }

    public String getMax_account() {
        return max_account;
    }

    public void setMax_account(String max_account) {
        this.max_account = max_account;
    }

    public String getCollection_wait() {
        return collection_wait;
    }

    public void setCollection_wait(String collection_wait) {
        this.collection_wait = collection_wait;
    }

    public String getCollection_yes() {
        return collection_yes;
    }

    public void setCollection_yes(String collection_yes) {
        this.collection_yes = collection_yes;
    }

    public String getCollection_capital1() {
        return collection_capital1;
    }

    public void setCollection_capital1(String collection_capital1) {
        this.collection_capital1 = collection_capital1;
    }

    public String getCollection_repaytime() {
        return collection_repaytime;
    }

    public void setCollection_repaytime(String collection_repaytime) {
        this.collection_repaytime = collection_repaytime;
    }

    public String getWait_payment() {
        return wait_payment;
    }

    public void setWait_payment(String wait_payment) {
        this.wait_payment = wait_payment;
    }

    public String getBorrow_num() {
        return borrow_num;
    }

    public void setBorrow_num(String borrow_num) {
        this.borrow_num = borrow_num;
    }

    public String getUse_amount() {
        return use_amount;
    }

    public void setUse_amount(String use_amount) {
        this.use_amount = use_amount;
    }

    public Object getId() {
        return id;
    }

    public void setId(Object id) {
        this.id = id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public Object getCredit() {
        return credit;
    }

    public void setCredit(Object credit) {
        this.credit = credit;
    }

    public String getCredit_use() {
        return credit_use;
    }

    public void setCredit_use(String credit_use) {
        this.credit_use = credit_use;
    }

    public String getCredit_nouse() {
        return credit_nouse;
    }

    public void setCredit_nouse(String credit_nouse) {
        this.credit_nouse = credit_nouse;
    }

    public String getBorrow_vouch() {
        return borrow_vouch;
    }

    public void setBorrow_vouch(String borrow_vouch) {
        this.borrow_vouch = borrow_vouch;
    }

    public String getBorrow_vouch_use() {
        return borrow_vouch_use;
    }

    public void setBorrow_vouch_use(String borrow_vouch_use) {
        this.borrow_vouch_use = borrow_vouch_use;
    }

    public String getBorrow_vouch_nouse() {
        return borrow_vouch_nouse;
    }

    public void setBorrow_vouch_nouse(String borrow_vouch_nouse) {
        this.borrow_vouch_nouse = borrow_vouch_nouse;
    }

    public String getTender_vouch() {
        return tender_vouch;
    }

    public void setTender_vouch(String tender_vouch) {
        this.tender_vouch = tender_vouch;
    }

    public String getTender_vouch_use() {
        return tender_vouch_use;
    }

    public void setTender_vouch_use(String tender_vouch_use) {
        this.tender_vouch_use = tender_vouch_use;
    }

    public String getTender_vouch_nouse() {
        return tender_vouch_nouse;
    }

    public void setTender_vouch_nouse(String tender_vouch_nouse) {
        this.tender_vouch_nouse = tender_vouch_nouse;
    }

    public String getNew_repay_time() {
        return new_repay_time;
    }

    public void setNew_repay_time(String new_repay_time) {
        this.new_repay_time = new_repay_time;
    }

    public String getNew_repay_account() {
        return new_repay_account;
    }

    public void setNew_repay_account(String new_repay_account) {
        this.new_repay_account = new_repay_account;
    }

    public String getNew_collection_time() {
        return new_collection_time;
    }

    public void setNew_collection_time(String new_collection_time) {
        this.new_collection_time = new_collection_time;
    }

    public String getNew_collection_account() {
        return new_collection_account;
    }

    public void setNew_collection_account(String new_collection_account) {
        this.new_collection_account = new_collection_account;
    }

    public Object getNum_late_repay_account() {
        return num_late_repay_account;
    }

    public void setNum_late_repay_account(Object num_late_repay_account) {
        this.num_late_repay_account = num_late_repay_account;
    }

    public Object getNum_late_interes() {
        return num_late_interes;
    }

    public void setNum_late_interes(Object num_late_interes) {
        this.num_late_interes = num_late_interes;
    }

    public double getNo_use_money() {
        return no_use_money;
    }

    public void setNo_use_money(double no_use_money) {
        this.no_use_money = no_use_money;
    }

    public Object getCredit_fen() {
        return credit_fen;
    }

    public void setCredit_fen(Object credit_fen) {
        this.credit_fen = credit_fen;
    }

    public String getTypepurview() {
        return typepurview;
    }

    public void setTypepurview(String typepurview) {
        this.typepurview = typepurview;
    }

    public String getTypename() {
        return typename;
    }

    public void setTypename(String typename) {
        this.typename = typename;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Object getKefu_userid() {
        return kefu_userid;
    }

    public void setKefu_userid(Object kefu_userid) {
        this.kefu_userid = kefu_userid;
    }

    public Object getKefu_username() {
        return kefu_username;
    }

    public void setKefu_username(Object kefu_username) {
        this.kefu_username = kefu_username;
    }

    public Object getKefu_addtime() {
        return kefu_addtime;
    }

    public void setKefu_addtime(Object kefu_addtime) {
        this.kefu_addtime = kefu_addtime;
    }

    public String getVip_status() {
        return vip_status;
    }

    public void setVip_status(String vip_status) {
        this.vip_status = vip_status;
    }

    public Object getVip_remark() {
        return vip_remark;
    }

    public void setVip_remark(Object vip_remark) {
        this.vip_remark = vip_remark;
    }

    public Object getVip_money() {
        return vip_money;
    }

    public void setVip_money(Object vip_money) {
        this.vip_money = vip_money;
    }

    public Object getVip_verify_remark() {
        return vip_verify_remark;
    }

    public void setVip_verify_remark(Object vip_verify_remark) {
        this.vip_verify_remark = vip_verify_remark;
    }

    public Object getVip_verify_time() {
        return vip_verify_time;
    }

    public void setVip_verify_time(Object vip_verify_time) {
        this.vip_verify_time = vip_verify_time;
    }

    public String getBbs_topics_num() {
        return bbs_topics_num;
    }

    public void setBbs_topics_num(String bbs_topics_num) {
        this.bbs_topics_num = bbs_topics_num;
    }

    public String getBbs_posts_num() {
        return bbs_posts_num;
    }

    public void setBbs_posts_num(String bbs_posts_num) {
        this.bbs_posts_num = bbs_posts_num;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getAccount_use() {
        return account_use;
    }

    public void setAccount_use(String account_use) {
        this.account_use = account_use;
    }

    public String getAccount_nouse() {
        return account_nouse;
    }

    public void setAccount_nouse(String account_nouse) {
        this.account_nouse = account_nouse;
    }

    public String getAccount_waitin() {
        return account_waitin;
    }

    public void setAccount_waitin(String account_waitin) {
        this.account_waitin = account_waitin;
    }

    public String getAccount_waitintrest() {
        return account_waitintrest;
    }

    public void setAccount_waitintrest(String account_waitintrest) {
        this.account_waitintrest = account_waitintrest;
    }

    public String getAccount_intrest() {
        return account_intrest;
    }

    public void setAccount_intrest(String account_intrest) {
        this.account_intrest = account_intrest;
    }

    public String getAccount_award() {
        return account_award;
    }

    public void setAccount_award(String account_award) {
        this.account_award = account_award;
    }

    public String getAccount_payment() {
        return account_payment;
    }

    public void setAccount_payment(String account_payment) {
        this.account_payment = account_payment;
    }

    public String getAccount_expired() {
        return account_expired;
    }

    public void setAccount_expired(String account_expired) {
        this.account_expired = account_expired;
    }

    public String getAccount_waitvip() {
        return account_waitvip;
    }

    public void setAccount_waitvip(String account_waitvip) {
        this.account_waitvip = account_waitvip;
    }

    public String getBorrow_amount() {
        return borrow_amount;
    }

    public void setBorrow_amount(String borrow_amount) {
        this.borrow_amount = borrow_amount;
    }

    public String getVouch_amount() {
        return vouch_amount;
    }

    public void setVouch_amount(String vouch_amount) {
        this.vouch_amount = vouch_amount;
    }

    public String getBorrow_loan() {
        return borrow_loan;
    }

    public void setBorrow_loan(String borrow_loan) {
        this.borrow_loan = borrow_loan;
    }

    public String getBorrow_success() {
        return borrow_success;
    }

    public void setBorrow_success(String borrow_success) {
        this.borrow_success = borrow_success;
    }

    public String getBorrow_wait() {
        return borrow_wait;
    }

    public void setBorrow_wait(String borrow_wait) {
        this.borrow_wait = borrow_wait;
    }

    public String getBorrow_paymeng() {
        return borrow_paymeng;
    }

    public void setBorrow_paymeng(String borrow_paymeng) {
        this.borrow_paymeng = borrow_paymeng;
    }

    public String getFriends_apply() {
        return friends_apply;
    }

    public void setFriends_apply(String friends_apply) {
        this.friends_apply = friends_apply;
    }

    public Object getVip_deadline() {
        return vip_deadline;
    }

    public void setVip_deadline(Object vip_deadline) {
        this.vip_deadline = vip_deadline;
    }

    public Object getVip_newmoney() {
        return vip_newmoney;
    }

    public void setVip_newmoney(Object vip_newmoney) {
        this.vip_newmoney = vip_newmoney;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getUse_money() {
        return use_money;
    }

    public void setUse_money(double use_money) {
        this.use_money = use_money;
    }

    public float getCollection() {
        return collection;
    }

    public void setCollection(float collection) {
        this.collection = collection;
    }

    public Object getXutou() {
        return xutou;
    }

    public void setXutou(Object xutou) {
        this.xutou = xutou;
    }

    public Object getFund() {
        return fund;
    }

    public void setFund(Object fund) {
        this.fund = fund;
    }

    public Object getLockmoney() {
        return lockmoney;
    }

    public void setLockmoney(Object lockmoney) {
        this.lockmoney = lockmoney;
    }

    public Object getXtcoll() {
        return xtcoll;
    }

    public void setXtcoll(Object xtcoll) {
        this.xtcoll = xtcoll;
    }

    public Object getLock_xtcoll() {
        return lock_xtcoll;
    }

    public void setLock_xtcoll(Object lock_xtcoll) {
        this.lock_xtcoll = lock_xtcoll;
    }

    public Object getXtjl() {
        return xtjl;
    }

    public void setXtjl(Object xtjl) {
        this.xtjl = xtjl;
    }

    public Object getSite_id() {
        return site_id;
    }

    public void setSite_id(Object site_id) {
        this.site_id = site_id;
    }

    public Object getName() {
        return name;
    }

    public void setName(Object name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Object getOrder() {
        return order;
    }

    public void setOrder(Object order) {
        this.order = order;
    }

    public Object getHits() {
        return hits;
    }

    public void setHits(Object hits) {
        this.hits = hits;
    }

    public Object getLitpic() {
        return litpic;
    }

    public void setLitpic(Object litpic) {
        this.litpic = litpic;
    }

    public Object getFlag() {
        return flag;
    }

    public void setFlag(Object flag) {
        this.flag = flag;
    }

    public Object getSource() {
        return source;
    }

    public void setSource(Object source) {
        this.source = source;
    }

    public Object getPublish() {
        return publish;
    }

    public void setPublish(Object publish) {
        this.publish = publish;
    }

    public Object getMarry() {
        return marry;
    }

    public void setMarry(Object marry) {
        this.marry = marry;
    }

    public Object getChild() {
        return child;
    }

    public void setChild(Object child) {
        this.child = child;
    }

    public Object getEducation() {
        return education;
    }

    public void setEducation(Object education) {
        this.education = education;
    }

    public Object getIncome() {
        return income;
    }

    public void setIncome(Object income) {
        this.income = income;
    }

    public Object getShebao() {
        return shebao;
    }

    public void setShebao(Object shebao) {
        this.shebao = shebao;
    }

    public Object getShebaoid() {
        return shebaoid;
    }

    public void setShebaoid(Object shebaoid) {
        this.shebaoid = shebaoid;
    }

    public Object getHousing() {
        return housing;
    }

    public void setHousing(Object housing) {
        this.housing = housing;
    }

    public Object getCar() {
        return car;
    }

    public void setCar(Object car) {
        this.car = car;
    }

    public Object getLate() {
        return late;
    }

    public void setLate(Object late) {
        this.late = late;
    }

    public Object getHouse_address() {
        return house_address;
    }

    public void setHouse_address(Object house_address) {
        this.house_address = house_address;
    }

    public Object getHouse_area() {
        return house_area;
    }

    public void setHouse_area(Object house_area) {
        this.house_area = house_area;
    }

    public Object getHouse_year() {
        return house_year;
    }

    public void setHouse_year(Object house_year) {
        this.house_year = house_year;
    }

    public Object getHouse_status() {
        return house_status;
    }

    public void setHouse_status(Object house_status) {
        this.house_status = house_status;
    }

    public Object getHouse_holder1() {
        return house_holder1;
    }

    public void setHouse_holder1(Object house_holder1) {
        this.house_holder1 = house_holder1;
    }

    public Object getHouse_holder2() {
        return house_holder2;
    }

    public void setHouse_holder2(Object house_holder2) {
        this.house_holder2 = house_holder2;
    }

    public Object getHouse_right1() {
        return house_right1;
    }

    public void setHouse_right1(Object house_right1) {
        this.house_right1 = house_right1;
    }

    public Object getHouse_right2() {
        return house_right2;
    }

    public void setHouse_right2(Object house_right2) {
        this.house_right2 = house_right2;
    }

    public Object getHouse_loanyear() {
        return house_loanyear;
    }

    public void setHouse_loanyear(Object house_loanyear) {
        this.house_loanyear = house_loanyear;
    }

    public Object getHouse_loanprice() {
        return house_loanprice;
    }

    public void setHouse_loanprice(Object house_loanprice) {
        this.house_loanprice = house_loanprice;
    }

    public Object getHouse_balance() {
        return house_balance;
    }

    public void setHouse_balance(Object house_balance) {
        this.house_balance = house_balance;
    }

    public Object getHouse_bank() {
        return house_bank;
    }

    public void setHouse_bank(Object house_bank) {
        this.house_bank = house_bank;
    }

    public Object getCompany_name() {
        return company_name;
    }

    public void setCompany_name(Object company_name) {
        this.company_name = company_name;
    }

    public Object getCompany_type() {
        return company_type;
    }

    public void setCompany_type(Object company_type) {
        this.company_type = company_type;
    }

    public Object getCompany_industry() {
        return company_industry;
    }

    public void setCompany_industry(Object company_industry) {
        this.company_industry = company_industry;
    }

    public Object getCompany_office() {
        return company_office;
    }

    public void setCompany_office(Object company_office) {
        this.company_office = company_office;
    }

    public Object getCompany_jibie() {
        return company_jibie;
    }

    public void setCompany_jibie(Object company_jibie) {
        this.company_jibie = company_jibie;
    }

    public Object getCompany_worktime1() {
        return company_worktime1;
    }

    public void setCompany_worktime1(Object company_worktime1) {
        this.company_worktime1 = company_worktime1;
    }

    public Object getCompany_worktime2() {
        return company_worktime2;
    }

    public void setCompany_worktime2(Object company_worktime2) {
        this.company_worktime2 = company_worktime2;
    }

    public Object getCompany_workyear() {
        return company_workyear;
    }

    public void setCompany_workyear(Object company_workyear) {
        this.company_workyear = company_workyear;
    }

    public Object getCompany_tel() {
        return company_tel;
    }

    public void setCompany_tel(Object company_tel) {
        this.company_tel = company_tel;
    }

    public Object getCompany_address() {
        return company_address;
    }

    public void setCompany_address(Object company_address) {
        this.company_address = company_address;
    }

    public Object getCompany_weburl() {
        return company_weburl;
    }

    public void setCompany_weburl(Object company_weburl) {
        this.company_weburl = company_weburl;
    }

    public Object getCompany_reamrk() {
        return company_reamrk;
    }

    public void setCompany_reamrk(Object company_reamrk) {
        this.company_reamrk = company_reamrk;
    }

    public Object getPrivate_type() {
        return private_type;
    }

    public void setPrivate_type(Object private_type) {
        this.private_type = private_type;
    }

    public Object getPrivate_date() {
        return private_date;
    }

    public void setPrivate_date(Object private_date) {
        this.private_date = private_date;
    }

    public Object getPrivate_place() {
        return private_place;
    }

    public void setPrivate_place(Object private_place) {
        this.private_place = private_place;
    }

    public Object getPrivate_rent() {
        return private_rent;
    }

    public void setPrivate_rent(Object private_rent) {
        this.private_rent = private_rent;
    }

    public Object getPrivate_term() {
        return private_term;
    }

    public void setPrivate_term(Object private_term) {
        this.private_term = private_term;
    }

    public Object getPrivate_taxid() {
        return private_taxid;
    }

    public void setPrivate_taxid(Object private_taxid) {
        this.private_taxid = private_taxid;
    }

    public Object getPrivate_commerceid() {
        return private_commerceid;
    }

    public void setPrivate_commerceid(Object private_commerceid) {
        this.private_commerceid = private_commerceid;
    }

    public Object getPrivate_income() {
        return private_income;
    }

    public void setPrivate_income(Object private_income) {
        this.private_income = private_income;
    }

    public Object getPrivate_employee() {
        return private_employee;
    }

    public void setPrivate_employee(Object private_employee) {
        this.private_employee = private_employee;
    }

    public Object getFinance_repayment() {
        return finance_repayment;
    }

    public void setFinance_repayment(Object finance_repayment) {
        this.finance_repayment = finance_repayment;
    }

    public Object getFinance_property() {
        return finance_property;
    }

    public void setFinance_property(Object finance_property) {
        this.finance_property = finance_property;
    }

    public Object getFinance_amount() {
        return finance_amount;
    }

    public void setFinance_amount(Object finance_amount) {
        this.finance_amount = finance_amount;
    }

    public Object getFinance_car() {
        return finance_car;
    }

    public void setFinance_car(Object finance_car) {
        this.finance_car = finance_car;
    }

    public Object getFinance_caramount() {
        return finance_caramount;
    }

    public void setFinance_caramount(Object finance_caramount) {
        this.finance_caramount = finance_caramount;
    }

    public Object getFinance_creditcard() {
        return finance_creditcard;
    }

    public void setFinance_creditcard(Object finance_creditcard) {
        this.finance_creditcard = finance_creditcard;
    }

    public Object getMate_name() {
        return mate_name;
    }

    public void setMate_name(Object mate_name) {
        this.mate_name = mate_name;
    }

    public Object getMate_salary() {
        return mate_salary;
    }

    public void setMate_salary(Object mate_salary) {
        this.mate_salary = mate_salary;
    }

    public Object getMate_phone() {
        return mate_phone;
    }

    public void setMate_phone(Object mate_phone) {
        this.mate_phone = mate_phone;
    }

    public Object getMate_tel() {
        return mate_tel;
    }

    public void setMate_tel(Object mate_tel) {
        this.mate_tel = mate_tel;
    }

    public Object getMate_type() {
        return mate_type;
    }

    public void setMate_type(Object mate_type) {
        this.mate_type = mate_type;
    }

    public Object getMate_office() {
        return mate_office;
    }

    public void setMate_office(Object mate_office) {
        this.mate_office = mate_office;
    }

    public Object getMate_address() {
        return mate_address;
    }

    public void setMate_address(Object mate_address) {
        this.mate_address = mate_address;
    }

    public Object getMate_income() {
        return mate_income;
    }

    public void setMate_income(Object mate_income) {
        this.mate_income = mate_income;
    }

    public Object getEducation_record() {
        return education_record;
    }

    public void setEducation_record(Object education_record) {
        this.education_record = education_record;
    }

    public Object getEducation_school() {
        return education_school;
    }

    public void setEducation_school(Object education_school) {
        this.education_school = education_school;
    }

    public Object getEducation_study() {
        return education_study;
    }

    public void setEducation_study(Object education_study) {
        this.education_study = education_study;
    }

    public Object getEducation_time1() {
        return education_time1;
    }

    public void setEducation_time1(Object education_time1) {
        this.education_time1 = education_time1;
    }

    public Object getEducation_time2() {
        return education_time2;
    }

    public void setEducation_time2(Object education_time2) {
        this.education_time2 = education_time2;
    }

    public Object getTel() {
        return tel;
    }

    public void setTel(Object tel) {
        this.tel = tel;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Object getPost() {
        return post;
    }

    public void setPost(Object post) {
        this.post = post;
    }

    public Object getAddress() {
        return address;
    }

    public void setAddress(Object address) {
        this.address = address;
    }

    public Object getProvince() {
        return province;
    }

    public void setProvince(Object province) {
        this.province = province;
    }

    public Object getCity() {
        return city;
    }

    public void setCity(Object city) {
        this.city = city;
    }

    public Object getArea() {
        return area;
    }

    public void setArea(Object area) {
        this.area = area;
    }

    public Object getLinkman1() {
        return linkman1;
    }

    public void setLinkman1(Object linkman1) {
        this.linkman1 = linkman1;
    }

    public Object getRelation1() {
        return relation1;
    }

    public void setRelation1(Object relation1) {
        this.relation1 = relation1;
    }

    public Object getTel1() {
        return tel1;
    }

    public void setTel1(Object tel1) {
        this.tel1 = tel1;
    }

    public Object getPhone1() {
        return phone1;
    }

    public void setPhone1(Object phone1) {
        this.phone1 = phone1;
    }

    public Object getLinkman2() {
        return linkman2;
    }

    public void setLinkman2(Object linkman2) {
        this.linkman2 = linkman2;
    }

    public Object getRelation2() {
        return relation2;
    }

    public void setRelation2(Object relation2) {
        this.relation2 = relation2;
    }

    public Object getTel2() {
        return tel2;
    }

    public void setTel2(Object tel2) {
        this.tel2 = tel2;
    }

    public Object getPhone2() {
        return phone2;
    }

    public void setPhone2(Object phone2) {
        this.phone2 = phone2;
    }

    public Object getLinkman3() {
        return linkman3;
    }

    public void setLinkman3(Object linkman3) {
        this.linkman3 = linkman3;
    }

    public Object getRelation3() {
        return relation3;
    }

    public void setRelation3(Object relation3) {
        this.relation3 = relation3;
    }

    public Object getTel3() {
        return tel3;
    }

    public void setTel3(Object tel3) {
        this.tel3 = tel3;
    }

    public Object getPhone3() {
        return phone3;
    }

    public void setPhone3(Object phone3) {
        this.phone3 = phone3;
    }

    public Object getMsn() {
        return msn;
    }

    public void setMsn(Object msn) {
        this.msn = msn;
    }

    public Object getQq() {
        return qq;
    }

    public void setQq(Object qq) {
        this.qq = qq;
    }

    public Object getWangwang() {
        return wangwang;
    }

    public void setWangwang(Object wangwang) {
        this.wangwang = wangwang;
    }

    public Object getAbility() {
        return ability;
    }

    public void setAbility(Object ability) {
        this.ability = ability;
    }

    public Object getInterest() {
        return interest;
    }

    public void setInterest(Object interest) {
        this.interest = interest;
    }

    public Object getOthers() {
        return others;
    }

    public void setOthers(Object others) {
        this.others = others;
    }

    public Object getExperience() {
        return experience;
    }

    public void setExperience(Object experience) {
        this.experience = experience;
    }

    public Object getSex() {
        return sex;
    }

    public void setSex(Object sex) {
        this.sex = sex;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }

    public String getAddip() {
        return addip;
    }

    public void setAddip(String addip) {
        this.addip = addip;
    }

    public Object getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Object updatetime) {
        this.updatetime = updatetime;
    }

    public Object getUpdateip() {
        return updateip;
    }

    public void setUpdateip(Object updateip) {
        this.updateip = updateip;
    }

    public String getType_id() {
        return type_id;
    }

    public void setType_id(String type_id) {
        this.type_id = type_id;
    }

    public Object getPurview() {
        return purview;
    }

    public void setPurview(Object purview) {
        this.purview = purview;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Object getPaypassword() {
        return paypassword;
    }

    public void setPaypassword(Object paypassword) {
        this.paypassword = paypassword;
    }

    public String getIslock() {
        return islock;
    }

    public void setIslock(String islock) {
        this.islock = islock;
    }

    public String getIsinvite() {
        return isinvite;
    }

    public void setIsinvite(String isinvite) {
        this.isinvite = isinvite;
    }

    public Object getInvite_userid() {
        return invite_userid;
    }

    public void setInvite_userid(Object invite_userid) {
        this.invite_userid = invite_userid;
    }

    public String getInvite_money() {
        return invite_money;
    }

    public void setInvite_money(String invite_money) {
        this.invite_money = invite_money;
    }

    public Object getReal_status() {
        return real_status;
    }

    public void setReal_status(Object real_status) {
        this.real_status = real_status;
    }

    public Object getCard_type() {
        return card_type;
    }

    public void setCard_type(Object card_type) {
        this.card_type = card_type;
    }

    public Object getCard_id() {
        return card_id;
    }

    public void setCard_id(Object card_id) {
        this.card_id = card_id;
    }

    public Object getCard_pic1() {
        return card_pic1;
    }

    public void setCard_pic1(Object card_pic1) {
        this.card_pic1 = card_pic1;
    }

    public Object getCard_pic2() {
        return card_pic2;
    }

    public void setCard_pic2(Object card_pic2) {
        this.card_pic2 = card_pic2;
    }

    public Object getNation() {
        return nation;
    }

    public void setNation(Object nation) {
        this.nation = nation;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }

    public String getInvest_integral() {
        return invest_integral;
    }

    public void setInvest_integral(String invest_integral) {
        this.invest_integral = invest_integral;
    }

    public String getWx_invest_integral() {
        return wx_invest_integral;
    }

    public void setWx_invest_integral(String wx_invest_integral) {
        this.wx_invest_integral = wx_invest_integral;
    }

    public String getAvatar_status() {
        return avatar_status;
    }

    public void setAvatar_status(String avatar_status) {
        this.avatar_status = avatar_status;
    }

    public Object getEmail_status() {
        return email_status;
    }

    public void setEmail_status(Object email_status) {
        this.email_status = email_status;
    }

    public String getPhone_status() {
        return phone_status;
    }

    public void setPhone_status(String phone_status) {
        this.phone_status = phone_status;
    }

    public String getVideo_status() {
        return video_status;
    }

    public void setVideo_status(String video_status) {
        this.video_status = video_status;
    }

    public String getScene_status() {
        return scene_status;
    }

    public void setScene_status(String scene_status) {
        this.scene_status = scene_status;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Object getQuestion() {
        return question;
    }

    public void setQuestion(Object question) {
        this.question = question;
    }

    public Object getAnswer() {
        return answer;
    }

    public void setAnswer(Object answer) {
        this.answer = answer;
    }

    public Object getBirthday() {
        return birthday;
    }

    public void setBirthday(Object birthday) {
        this.birthday = birthday;
    }

    public Object getRemind() {
        return remind;
    }

    public void setRemind(Object remind) {
        this.remind = remind;
    }

    public String getPrivacy() {
        return privacy;
    }

    public void setPrivacy(String privacy) {
        this.privacy = privacy;
    }

    public String getLogintime() {
        return logintime;
    }

    public void setLogintime(String logintime) {
        this.logintime = logintime;
    }

    public String getUptime() {
        return uptime;
    }

    public void setUptime(String uptime) {
        this.uptime = uptime;
    }

    public String getUpip() {
        return upip;
    }

    public void setUpip(String upip) {
        this.upip = upip;
    }

    public String getLasttime() {
        return lasttime;
    }

    public void setLasttime(String lasttime) {
        this.lasttime = lasttime;
    }

    public String getLastip() {
        return lastip;
    }

    public void setLastip(String lastip) {
        this.lastip = lastip;
    }

    public String getChongzu_id() {
        return chongzu_id;
    }

    public void setChongzu_id(String chongzu_id) {
        this.chongzu_id = chongzu_id;
    }

    public String getCz_money() {
        return cz_money;
    }

    public void setCz_money(String cz_money) {
        this.cz_money = cz_money;
    }

    public String getCz_cash() {
        return cz_cash;
    }

    public void setCz_cash(String cz_cash) {
        this.cz_cash = cz_cash;
    }

    public String getChongzu_new_id() {
        return chongzu_new_id;
    }

    public void setChongzu_new_id(String chongzu_new_id) {
        this.chongzu_new_id = chongzu_new_id;
    }

    public Object getUsecredit() {
        return usecredit;
    }

    public void setUsecredit(Object usecredit) {
        this.usecredit = usecredit;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getHeadimg() {
        return headimg;
    }

    public void setHeadimg(String headimg) {
        this.headimg = headimg;
    }
}
