package com.daiqile.test.model;

/**
 * Created by ZHY_9 on 2017/6/30.
 */

public class UsersInfo {

        private String user_id;
        private String username;
        private String type_id;
        private String real_status;
        private String is_authorize;
        private String card_id;
        private String phone;
        private String order;
        private String purview;
        private String password;
        private String paypassword;
        private String islock;
        private String isinvite;
        private String invite_userid;
        private String invite_money;
        private String card_type;
        private String card_pic1;
        private String card_pic2;
        private String nation;
        private String realname;
        private String integral;
        private String invest_integral;
        private String wx_invest_integral;
        private String status;
        private String avatar_status;
        private String email_status;
        private String phone_status;
        private String video_status;
        private String scene_status;
        private String email;
        private String sex;
        private String litpic;
        private String tel;
        private String qq;
        private String wangwang;
        private String question;
        private String answer;
        private String birthday;
        private String province;
        private String city;
        private String area;
        private String address;
        private String remind;
        private String privacy;
        private String logintime;
        private String addtime;
        private String addip;
        private String uptime;
        private String upip;
        private String lasttime;
        private String lastip;
        private String chongzu_id;
        private String cz_money;
        private String cz_cash;
        private String chongzu_new_id;
        private String yemadai_mode;
        private String is_red_packet;
        private String bank_card;
        private String qq_access_token;
        private String qq_openid;
        private String wx_access_token;
        private String wx_openid;

        public void setUser_id(String user_id) {
            this.user_id = user_id;
        }
        public String getUser_id() {
            return user_id;
        }

        public void setUsername(String username) {
            this.username = username;
        }
        public String getUsername() {
            return username;
        }

        public void setType_id(String type_id) {
            this.type_id = type_id;
        }
        public String getType_id() {
            return type_id;
        }

        public void setReal_status(String real_status) {
            this.real_status = real_status;
        }
        public String getReal_status() {
            return real_status;
        }

        public void setIs_authorize(String is_authorize) {
            this.is_authorize = is_authorize;
        }
        public String getIs_authorize() {
            return is_authorize;
        }

        public void setCard_id(String card_id) {
            this.card_id = card_id;
        }
        public String getCard_id() {
            return card_id;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }
        public String getPhone() {
            return phone;
        }

        public void setOrder(String order) {
            this.order = order;
        }
        public String getOrder() {
            return order;
        }

        public void setPurview(String purview) {
            this.purview = purview;
        }
        public String getPurview() {
            return purview;
        }

        public void setPassword(String password) {
            this.password = password;
        }
        public String getPassword() {
            return password;
        }

        public void setPaypassword(String paypassword) {
            this.paypassword = paypassword;
        }
        public String getPaypassword() {
            return paypassword;
        }

        public void setIslock(String islock) {
            this.islock = islock;
        }
        public String getIslock() {
            return islock;
        }

        public void setIsinvite(String isinvite) {
            this.isinvite = isinvite;
        }
        public String getIsinvite() {
            return isinvite;
        }

        public void setInvite_userid(String invite_userid) {
            this.invite_userid = invite_userid;
        }
        public String getInvite_userid() {
            return invite_userid;
        }

        public void setInvite_money(String invite_money) {
            this.invite_money = invite_money;
        }
        public String getInvite_money() {
            return invite_money;
        }

        public void setCard_type(String card_type) {
            this.card_type = card_type;
        }
        public String getCard_type() {
            return card_type;
        }

        public void setCard_pic1(String card_pic1) {
            this.card_pic1 = card_pic1;
        }
        public String getCard_pic1() {
            return card_pic1;
        }

        public void setCard_pic2(String card_pic2) {
            this.card_pic2 = card_pic2;
        }
        public String getCard_pic2() {
            return card_pic2;
        }

        public void setNation(String nation) {
            this.nation = nation;
        }
        public String getNation() {
            return nation;
        }

        public void setRealname(String realname) {
            this.realname = realname;
        }
        public String getRealname() {
            return realname;
        }

        public void setIntegral(String integral) {
            this.integral = integral;
        }
        public String getIntegral() {
            return integral;
        }

        public void setInvest_integral(String invest_integral) {
            this.invest_integral = invest_integral;
        }
        public String getInvest_integral() {
            return invest_integral;
        }

        public void setWx_invest_integral(String wx_invest_integral) {
            this.wx_invest_integral = wx_invest_integral;
        }
        public String getWx_invest_integral() {
            return wx_invest_integral;
        }

        public void setStatus(String status) {
            this.status = status;
        }
        public String getStatus() {
            return status;
        }

        public void setAvatar_status(String avatar_status) {
            this.avatar_status = avatar_status;
        }
        public String getAvatar_status() {
            return avatar_status;
        }

        public void setEmail_status(String email_status) {
            this.email_status = email_status;
        }
        public String getEmail_status() {
            return email_status;
        }

        public void setPhone_status(String phone_status) {
            this.phone_status = phone_status;
        }
        public String getPhone_status() {
            return phone_status;
        }

        public void setVideo_status(String video_status) {
            this.video_status = video_status;
        }
        public String getVideo_status() {
            return video_status;
        }

        public void setScene_status(String scene_status) {
            this.scene_status = scene_status;
        }
        public String getScene_status() {
            return scene_status;
        }

        public void setEmail(String email) {
            this.email = email;
        }
        public String getEmail() {
            return email;
        }

        public void setSex(String sex) {
            this.sex = sex;
        }
        public String getSex() {
            return sex;
        }

        public void setLitpic(String litpic) {
            this.litpic = litpic;
        }
        public String getLitpic() {
            return litpic;
        }

        public void setTel(String tel) {
            this.tel = tel;
        }
        public String getTel() {
            return tel;
        }

        public void setQq(String qq) {
            this.qq = qq;
        }
        public String getQq() {
            return qq;
        }

        public void setWangwang(String wangwang) {
            this.wangwang = wangwang;
        }
        public String getWangwang() {
            return wangwang;
        }

        public void setQuestion(String question) {
            this.question = question;
        }
        public String getQuestion() {
            return question;
        }

        public void setAnswer(String answer) {
            this.answer = answer;
        }
        public String getAnswer() {
            return answer;
        }

        public void setBirthday(String birthday) {
            this.birthday = birthday;
        }
        public String getBirthday() {
            return birthday;
        }

        public void setProvince(String province) {
            this.province = province;
        }
        public String getProvince() {
            return province;
        }

        public void setCity(String city) {
            this.city = city;
        }
        public String getCity() {
            return city;
        }

        public void setArea(String area) {
            this.area = area;
        }
        public String getArea() {
            return area;
        }

        public void setAddress(String address) {
            this.address = address;
        }
        public String getAddress() {
            return address;
        }

        public void setRemind(String remind) {
            this.remind = remind;
        }
        public String getRemind() {
            return remind;
        }

        public void setPrivacy(String privacy) {
            this.privacy = privacy;
        }
        public String getPrivacy() {
            return privacy;
        }

        public void setLogintime(String logintime) {
            this.logintime = logintime;
        }
        public String getLogintime() {
            return logintime;
        }

        public void setAddtime(String addtime) {
            this.addtime = addtime;
        }
        public String getAddtime() {
            return addtime;
        }

        public void setAddip(String addip) {
            this.addip = addip;
        }
        public String getAddip() {
            return addip;
        }

        public void setUptime(String uptime) {
            this.uptime = uptime;
        }
        public String getUptime() {
            return uptime;
        }

        public void setUpip(String upip) {
            this.upip = upip;
        }
        public String getUpip() {
            return upip;
        }

        public void setLasttime(String lasttime) {
            this.lasttime = lasttime;
        }
        public String getLasttime() {
            return lasttime;
        }

        public void setLastip(String lastip) {
            this.lastip = lastip;
        }
        public String getLastip() {
            return lastip;
        }

        public void setChongzu_id(String chongzu_id) {
            this.chongzu_id = chongzu_id;
        }
        public String getChongzu_id() {
            return chongzu_id;
        }

        public void setCz_money(String cz_money) {
            this.cz_money = cz_money;
        }
        public String getCz_money() {
            return cz_money;
        }

        public void setCz_cash(String cz_cash) {
            this.cz_cash = cz_cash;
        }
        public String getCz_cash() {
            return cz_cash;
        }

        public void setChongzu_new_id(String chongzu_new_id) {
            this.chongzu_new_id = chongzu_new_id;
        }
        public String getChongzu_new_id() {
            return chongzu_new_id;
        }

        public void setYemadai_mode(String yemadai_mode) {
            this.yemadai_mode = yemadai_mode;
        }
        public String getYemadai_mode() {
            return yemadai_mode;
        }

        public void setIs_red_packet(String is_red_packet) {
            this.is_red_packet = is_red_packet;
        }
        public String getIs_red_packet() {
            return is_red_packet;
        }

        public void setBank_card(String bank_card) {
            this.bank_card = bank_card;
        }
        public String getBank_card() {
            return bank_card;
        }

        public void setQq_access_token(String qq_access_token) {
            this.qq_access_token = qq_access_token;
        }
        public String getQq_access_token() {
            return qq_access_token;
        }

        public void setQq_openid(String qq_openid) {
            this.qq_openid = qq_openid;
        }
        public String getQq_openid() {
            return qq_openid;
        }

        public void setWx_access_token(String wx_access_token) {
            this.wx_access_token = wx_access_token;
        }
        public String getWx_access_token() {
            return wx_access_token;
        }

        public void setWx_openid(String wx_openid) {
            this.wx_openid = wx_openid;
        }
        public String getWx_openid() {
            return wx_openid;
        }
}
