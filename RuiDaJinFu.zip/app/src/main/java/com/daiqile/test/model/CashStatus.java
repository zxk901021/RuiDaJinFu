package com.daiqile.test.model;

/**
 * Created by Administrator on 2017/1/23.
 */

public class CashStatus {

    /**
     * cash_status : 0
     */

    private String cash_status;

    public String getCash_status() {
        return cash_status;
    }

    public void setCash_status(String cash_status) {
        this.cash_status = cash_status;
    }
}
