package com.daiqile.test.model;

import java.util.List;

/**
 * Created by 钱展杰 on 2017/4/25.
 */

public class Banner {

    private List<String> list;

    public List<String> getList() {
        return list;
    }

    public void setList(List<String> list) {
        this.list = list;
    }
}
