package com.daiqile.test;

/**
 * Created by orgwcl on 2016/9/2.
 */
public class Constants {
//    public static final String BASE_URL = "http://www.zjrdjr.com/port/";
    public static final String BASE_URL = "http://test2.zjrdjr.com/port/";
    public static final String DCODE = "7d5372bbcd6cc79f1bd71211f092622e";

    //cookies
    public static final String USERID = "id";
    public static final String USERNAMECOOKIE = "cookieName";
    public static final String USERPASSWORDCOOKIE = "cookiePassword";
    public static final String USERREMEMBERCOOKIE = "cookieRemember";
    public static final String ISFIRSTSTART = "isFirstStart";
    public static final String PHONECOOKIE = "cookiePhone";

}
