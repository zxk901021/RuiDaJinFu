package com.daiqile.test.model;

/**
 * Created by Administrator on 2016/12/14.
 */
public class TenderResult {
    private String tender_status;
    private String msg;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getTender_status() {
        return tender_status;
    }

    public void setTender_status(String tender_status) {
        this.tender_status = tender_status;
    }
}
