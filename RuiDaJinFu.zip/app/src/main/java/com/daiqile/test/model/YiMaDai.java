package com.daiqile.test.model;

/**
 * Created by Administrator on 2017/1/23.
 */
public class YiMaDai {

    /**
     * status : 0
     */

    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
