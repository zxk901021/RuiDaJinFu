package com.daiqile.test.model;

/**
 * Created by Administrator on 2016/12/21.
 */
public class PasswordResult {
    /**
     * set_status : 1
     */

    private String set_status;

    public String getSet_status() {
        return set_status;
    }

    public void setSet_status(String set_status) {
        this.set_status = set_status;
    }
}
