package com.daiqile.test.model;

/**
 * Created by Administrator on 2017/1/20.
 */

public class IsReal {

    /**
     * real_status : 0
     */

    private String real_status;

    public String getReal_status() {
        return real_status;
    }

    public void setReal_status(String real_status) {
        this.real_status = real_status;
    }
}
