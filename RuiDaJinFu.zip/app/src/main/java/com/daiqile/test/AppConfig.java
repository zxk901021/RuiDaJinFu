package com.daiqile.test;

public class AppConfig {
    public static String SHARED_PATH = "app_share";
}
