package com.daiqile.test.model;

/**
 * Created by ZHY_9 on 2017/7/5.
 */

public class RechargeModel {

    private String status;
    private String message;
    private String bizOrderNo;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getBizOrderNo() {
        return bizOrderNo;
    }

    public void setBizOrderNo(String bizOrderNo) {
        this.bizOrderNo = bizOrderNo;
    }
}
