package com.daiqile.test.model;

/**
 * Created by ZHY_9 on 2017/6/29.
 */

public class BindResult {

    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
